package com.virtusa.shipping.model;

import java.time.LocalDate;

import lombok.Data;

@Data
public class DeliverySchedule {
	
	private Long productId;
	private LocalDate requestDate;
	private LocalDate plannedDeliveryDate;
	private Long availableQty;

}
