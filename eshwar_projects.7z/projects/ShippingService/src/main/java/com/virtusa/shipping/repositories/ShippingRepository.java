package com.virtusa.shipping.repositories;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.query.Param;


import com.virtusa.shipping.model.StockStatusHistory;

public interface ShippingRepository extends MongoRepository<StockStatusHistory, Long> {
	
	@Query("Select stock from StockStatusHistory stockStatusHistory where stockStatusHistory.productId=:productId")
	public List<StockStatusHistory> getAllStockByProductId(@Param("productId") long productId);
	

}
