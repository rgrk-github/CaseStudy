package com.virtusa.shipping.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


import com.virtusa.shipping.service.KafKaProducerService;

public class ShippingController {
	
	@Autowired
	KafKaProducerService kafkaProducerService;
	
	@GetMapping("/shipping/v1.0/{productId}")
	public void publishPlannedDeliveryDate(@PathVariable("productId") long productId){
		kafkaProducerService.sendMessage(productId);
	}

}
