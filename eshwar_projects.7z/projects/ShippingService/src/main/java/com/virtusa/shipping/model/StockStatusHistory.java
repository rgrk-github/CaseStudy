package com.virtusa.shipping.model;

import java.time.LocalDate;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Document( collection = "StockStatusHistories")
@Data
public class StockStatusHistory {
	
	@Id
	private long historyId;
	private long productId;
	private long qty;
	private LocalDate timeStamp;
	
	public StockStatusHistory(long historyId, long productId, long qty, LocalDate timeStamp) {
		super();
		this.historyId = historyId;
		this.productId = productId;
		this.qty = qty;
		this.timeStamp = timeStamp;
	}
	

}
