package com.virtusa.ecommerce.controller;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.ecommerce.models.UserAccount;
import com.virtusa.ecommerce.service.UserQueryService;

import lombok.AllArgsConstructor;

@RestController
@RequestMapping(value = "/users")
@AllArgsConstructor
public class UserQueryController {
	
	private final UserQueryService userQueryService;

    @GetMapping("/{userName}")
    public CompletableFuture<UserAccount> findByUserName(@PathVariable("userName") String userName) {
        return this.userQueryService.findById(userName);
    }

    @GetMapping("/{userName}/events")
    public List<Object> listEventsForAccount(@PathVariable(value = "userName") String userName) {
        return this.userQueryService.listEventsForAccount(userName);
    }

}
