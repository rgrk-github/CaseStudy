package com.virtusa.ecommerce.dto;

import com.virtusa.ecommerce.command.CreateUserCommand;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserCreationDTO {
	private String userName;
	private String password;

}
